package com.cg.jpastart.entities;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

public class StudentTest {
	 static EntityManager em;

	public static void main(String[] args) {
			
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		em = factory.createEntityManager();
		em.getTransaction().begin();
		
		Employee emp = new Employee();
		emp.setName("Miky");
		emp.setAddress("NY");
		
		/*Student student = new Student();
		student.setName("JohnNew");
		Student student1 = new Student();
		student1.setName("RaushanNew");*/
		em.persist(emp);
		
	/*	em.persist(student);
		em.persist(student1);*/
		em.getTransaction().commit();
		
		/*System.out.println("Added one student to database.");
		StudentTest st= new StudentTest();
		st.StudentCount();*/
		
		List<Employee> l=empDetailsByName("Ram");
		System.out.println("Eneterd "+l.size());
		for(Employee data :l)
		{
			System.out.println(data.getName()+" "+data.getAddress());
		}
		getAllEmployee();
		em.close();
		factory.close();
			
	}
	public Long StudentCount()
	{
		String str="SELECT COUNT (student.studentId) FROM Student student";
		TypedQuery<Long> query= em.createQuery(str,Long.class);
		Long count= query.getSingleResult();
		System.out.println(count);
		return count;
	}
	
	public static List<Employee> empDetailsByName(String ename)
	{
		String str="SELECT emp from Employee emp where emp.address=:dummyname";
		TypedQuery<Employee> query= em.createQuery(str,Employee.class);
		query.setParameter("dummyname", ename);
		List<Employee> result= query.getResultList();
		return result;
	}
	public static List <Employee> getAllEmployee()
	{
		Query query= em.createNamedQuery("getAllBook");
		@SuppressWarnings("unchecked")
		List<Employee> emplist= query.getResultList();
		for(Employee data :emplist)
		{
			System.out.println(data.getName());
		}
		
		return emplist;
	}
}
